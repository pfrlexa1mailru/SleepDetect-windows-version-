﻿
#ifndef __LANDMARK_CORE_INCLUDES_h_
#define __LANDMARK_CORE_INCLUDES_h_

#include "LandmarkDetectorModel.h"
#include "LandmarkDetectorFunc.h"
#include "LandmarkDetectorParameters.h"
#include "LandmarkDetectorUtils.h"

#endif

#include <iostream>
#include <io.h>
#include <fcntl.h>

